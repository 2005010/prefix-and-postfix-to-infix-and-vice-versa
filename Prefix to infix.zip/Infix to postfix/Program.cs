﻿using System;
using System.Collections.Generic;

class Program
{
    static int precedence(char ch)
    {
        switch (ch)
        {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
        }
        return -1;
    }

    static string InfixToPostfix(string expression)
    {
        Stack<char> stack = new Stack<char>();
        string result = "";

        foreach (char ch in expression)
        {
            if (char.IsLetterOrDigit(ch))
            {
                result += ch;
            }
            else if (ch == '(')
            {
                stack.Push(ch);
            }
            else if ( ch == ')')
            { 
                while (stack.Count > 0 && stack.Peek() != '(')
                {
                    result += stack.Pop();
                }
                stack.Pop();
            }
            else
            {
                while (stack.Count > 0 && precedence(ch) <= precedence(stack.Peek()))
                {
                    result += stack.Pop();
                }
                stack.Push(ch);
            }
        }
        while (stack.Count > 0)
        {
        result += stack.Pop();
        }
        return result;
    }            
    public static void Main()
    {
    Console.WriteLine("Enter an infix expression: ");
    string? expression = Console.ReadLine();
    expression = expression ?? string.Empty; // Ensure expression is not null
    Console.WriteLine("Infix Expression: " + expression);
    Console.WriteLine(" Postfix Expression: " + InfixToPostfix(expression));
    }
}     
    