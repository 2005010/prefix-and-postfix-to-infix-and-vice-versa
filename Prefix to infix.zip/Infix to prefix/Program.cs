﻿using System;
using System.Collections.Generic;
using System.Data.Common;

class Program
{
    static int Precedence(char ch)
    {
        switch (ch)
        {
            case '+':
            case '-':
            return 1;
            case '*':
            case '/':
            return 2;
            case '^':
            return 3;
        }
        return -1;
    }

    static string InfixToPrefix(string expression)
    {
        Stack<char> operators = new Stack<char>();
        Stack<string> operands = new Stack<string>();

        for (int i = expression.Length - 1; i >= 0; i--)
        {
            char ch = expression[i];

            if(char.IsLetterOrDigit(ch))
            {
                operands.Push(ch.ToString());
            }
            else if (ch == ')')
            {
                operators.Push(ch);
            }
            else if (ch == '(')
            {
                while (operators.Count > 0 && operators.Peek() != ')' )
                {
                    string operand1 = operands.Pop();
                    string operand2 = operands.Pop();
                    char op = operators.Pop();
                    string subExpression = op + operand1 + operand2;
                    operands.Push(subExpression);
                }
                operators.Pop();
            }
            else
            {
                while (operators.Count > 0 && Precedence(ch) < Precedence(operators.Peek()))
                {
                    string operand1 = operands.Pop();
                    string operand2 = operands.Pop();
                    char op = operators.Pop();
                    string subExpression = op + operand1 + operand2;
                    operands.Push(subExpression);
                }
                operators.Push(ch);
            }
        }

        while (operators.Count > 0)
        {
            string operand1 = operands.Pop();
            string operand2 = operands.Pop();
            char op = operators.Pop();
            string subExpression = op + operand1 + operand2;
            operands.Push(subExpression);
        }

        return operands.Peek();
    }

    public static void Main()
    {
        Console.WriteLine("Enter an infix expression: ");
        string? expression = Console.ReadLine();
        expression = expression ?? string.Empty; // Ensure expression is not null 
        Console.WriteLine("Infix Expression: " + expression);
        Console.WriteLine("Prefix Expression: " + InfixToPrefix(expression));
    }
}
