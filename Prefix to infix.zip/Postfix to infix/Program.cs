﻿using System;
using System.Collections.Generic;

class Program
{
    static string PostfixToInfix(string expression)
    {
        Stack<string> stack = new Stack<string>();

        foreach (char ch in expression)
        {
            if (char.IsLetterOrDigit(ch))
            {
                stack.Push(ch.ToString());
            }
            else
            {
                string operand2 = stack.Pop();
                string operand1 = stack.Pop();
                string subExpression = "(" + operand1 + ch + operand2 + ")";
                stack.Push(subExpression);
            }
        }

        return stack.Pop();
    }

    public static void Main()
    {
        Console.WriteLine("Enter a postfix expression: ");
        string? expression = Console.ReadLine();
        expression = expression ?? string.Empty; // Ensure expression is not null 
        Console.WriteLine("Postfix Expression: " + expression);
        Console.WriteLine("Infix Expression: " + PostfixToInfix(expression));
    }
}
