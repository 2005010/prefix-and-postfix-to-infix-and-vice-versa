﻿using System;
using System.Collections.Generic;

class Program
{
    static string PrefixToInfix(string expression)
    {
        Stack<string> stack = new Stack<string>();

        for (int i = expression.Length - 1; i >= 0; i--)
        {
            char ch = expression[i];

            if(char.IsLetterOrDigit(ch))
            {
                stack.Push(ch.ToString());
            }
            else
            {
                string operand1 = stack.Pop();
                string operand2 = stack.Pop();
                string subExpression = "(" + operand1 + ch + operand2 + ")";
                stack.Push(subExpression);
            }
        }

        return stack.Peek();
    }

    public static void Main()
    {
        Console.WriteLine("Enter a prefix expression: ");
        string? expression = Console.ReadLine();
        expression = expression ?? string.Empty; // Ensure expression is not null
        Console.WriteLine("Prefix Expression: " + expression);
        Console.WriteLine("Infix Expression: " + PrefixToInfix(expression));
    }
}
